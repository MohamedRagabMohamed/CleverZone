public class Teacher extends Account {
	Teacher(String a,String b,String c,boolean t)
	{
		super(a,b,c,t);
	}
	Teacher(){}
}